<?php
include('includes/config.php');

try {
    // Check today's orders
    $stmt = $conn->prepare("SELECT id, order_number, created_at, total_amount, payment_status FROM orders WHERE DATE(created_at) = CURDATE() ORDER BY created_at DESC");
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>Today's Orders (" . date('Y-m-d') . ")</h2>";
    echo "<p>Total orders found: " . count($orders) . "</p>";
    
    if (empty($orders)) {
        echo "<p style='color: red;'>No orders found for today!</p>";
        
        // Check if there are any orders at all
        $stmt = $conn->prepare("SELECT COUNT(*) as total FROM orders");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "<p>Total orders in database: " . $result['total'] . "</p>";
        
        // Show last 5 orders
        $stmt = $conn->prepare("SELECT id, order_number, created_at, total_amount, payment_status FROM orders ORDER BY created_at DESC LIMIT 5");
        $stmt->execute();
        $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h3>Last 5 Orders:</h3>";
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Order #</th><th>Date</th><th>Amount</th><th>Status</th></tr>";
        foreach ($recent as $order) {
            echo "<tr>";
            echo "<td>" . $order['id'] . "</td>";
            echo "<td>" . $order['order_number'] . "</td>";
            echo "<td>" . $order['created_at'] . "</td>";
            echo "<td>₱" . number_format($order['total_amount'], 2) . "</td>";
            echo "<td>" . $order['payment_status'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<table border='1' style='border-collapse: collapse;'>";
        echo "<tr><th>ID</th><th>Order #</th><th>Date</th><th>Amount</th><th>Status</th></tr>";
        foreach ($orders as $order) {
            echo "<tr>";
            echo "<td>" . $order['id'] . "</td>";
            echo "<td>" . $order['order_number'] . "</td>";
            echo "<td>" . $order['created_at'] . "</td>";
            echo "<td>₱" . number_format($order['total_amount'], 2) . "</td>";
            echo "<td>" . $order['payment_status'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<br><br><a href='sales_report.php'>Back to Sales Report</a>";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
