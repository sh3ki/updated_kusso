<?php
/**
 * Auto Archive Cron Job
 * 
 * This script runs automatically to archive sales data and cleanup old archives.
 * 
 * Schedule this script to run daily at 2 AM using:
 * 
 * For Windows Task Scheduler:
 * - Open Task Scheduler
 * - Create Basic Task
 * - Name: "KUSSO Auto Archive"
 * - Trigger: Daily at 2:00 AM
 * - Action: Start a program
 * - Program: C:\laragon\bin\php\php-8.x.x\php.exe
 * - Arguments: "C:\laragon\www\kusso\auto_archive_cron.php"
 * 
 * For Linux/Mac cron:
 * 0 2 * * * /usr/bin/php /path/to/kusso/auto_archive_cron.php
 * 
 * Or via wget/curl:
 * 0 2 * * * curl http://localhost/kusso/auto_archive_cron.php
 */

// Only run from command line or localhost for security
$is_cli = php_sapi_name() === 'cli';
$is_localhost = isset($_SERVER['REMOTE_ADDR']) && in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1']);

if (!$is_cli && !$is_localhost) {
    http_response_code(403);
    die('Access denied. This script can only be run from localhost or command line.');
}

// Include necessary files
require_once(__DIR__ . '/includes/config.php');

// Log file for cron execution
$log_file = __DIR__ . '/logs/auto_archive.log';
$log_dir = dirname($log_file);

// Create log directory if it doesn't exist
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0755, true);
}

// Start logging
$log_time = date('Y-m-d H:i:s');
$log_message = "\n" . str_repeat('=', 70) . "\n";
$log_message .= "Auto Archive Started: {$log_time}\n";
$log_message .= str_repeat('=', 70) . "\n";

try {
    $messages = [];
    
    // Archive yesterday's data as daily
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    $result = archiveData($conn, 'daily', $yesterday, $yesterday);
    $messages[] = "Daily Archive: " . $result['message'];
    $log_message .= "✓ " . $messages[count($messages) - 1] . "\n";
    
    // Archive last week's data if it's Monday
    if (date('N') == 1) {
        $last_week_start = date('Y-m-d', strtotime('last monday -7 days'));
        $last_week_end = date('Y-m-d', strtotime('last sunday'));
        $result = archiveData($conn, 'weekly', $last_week_start, $last_week_end);
        $messages[] = "Weekly Archive: " . $result['message'];
        $log_message .= "✓ " . $messages[count($messages) - 1] . "\n";
    }
    
    // Archive last month's data if it's the 1st of the month
    if (date('j') == 1) {
        $last_month_start = date('Y-m-01', strtotime('first day of last month'));
        $last_month_end = date('Y-m-t', strtotime('last day of last month'));
        $result = archiveData($conn, 'monthly', $last_month_start, $last_month_end);
        $messages[] = "Monthly Archive: " . $result['message'];
        $log_message .= "✓ " . $messages[count($messages) - 1] . "\n";
    }
    
    // Run cleanup
    $log_message .= "\nRunning cleanup...\n";
    $cleanup_result = cleanupOldArchives($conn);
    
    foreach ($cleanup_result['messages'] as $msg) {
        $messages[] = "Cleanup: " . $msg;
        $log_message .= "✓ " . $msg . "\n";
    }
    
    $log_message .= "\n" . str_repeat('-', 70) . "\n";
    $log_message .= "Status: SUCCESS\n";
    $log_message .= "Total operations: " . count($messages) . "\n";
    $log_message .= str_repeat('=', 70) . "\n";
    
    // Write to log file
    file_put_contents($log_file, $log_message, FILE_APPEND);
    
    // Output for CLI
    if ($is_cli) {
        echo $log_message;
    } else {
        // JSON response for web access
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'timestamp' => $log_time,
            'messages' => $messages
        ]);
    }
    
} catch (Exception $e) {
    $error_message = "ERROR: " . $e->getMessage() . "\n";
    $error_message .= "Stack trace: " . $e->getTraceAsString() . "\n";
    $log_message .= $error_message;
    $log_message .= "Status: FAILED\n";
    $log_message .= str_repeat('=', 70) . "\n";
    
    file_put_contents($log_file, $log_message, FILE_APPEND);
    
    if ($is_cli) {
        echo $log_message;
        exit(1);
    } else {
        header('Content-Type: application/json');
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'timestamp' => $log_time
        ]);
    }
}

/**
 * Archive data for a specific period
 */
function archiveData($conn, $archive_type, $period_start, $period_end) {
    try {
        // Check if archive already exists
        $check_query = "SELECT id FROM sales_archives WHERE archive_type = ? AND period_start = ? AND period_end = ?";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->execute([$archive_type, $period_start, $period_end]);
        
        if ($check_stmt->fetch()) {
            return ['success' => false, 'message' => "Archive already exists for this period ({$period_start} to {$period_end})"];
        }
        
        // Get sales summary
        $summary_query = "
            SELECT 
                COUNT(DISTINCT o.id) as total_orders,
                SUM(o.total_amount) as total_sales,
                AVG(o.total_amount) as avg_order_value,
                SUM(CASE WHEN o.payment_status = 'paid' THEN o.total_amount ELSE 0 END) as paid_sales,
                SUM(CASE WHEN o.payment_status = 'unpaid' THEN o.total_amount ELSE 0 END) as unpaid_sales
            FROM orders o 
            WHERE DATE(o.created_at) BETWEEN ? AND ?
        ";
        
        $summary_stmt = $conn->prepare($summary_query);
        $summary_stmt->execute([$period_start, $period_end]);
        $summary = $summary_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get top product
        $products_query = "
            SELECT 
                p.product_name,
                SUM(oi.amount) as total_revenue
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            JOIN products p ON oi.product_id = p.id
            WHERE DATE(o.created_at) BETWEEN ? AND ?
            GROUP BY p.id, p.product_name
            ORDER BY total_revenue DESC
            LIMIT 1
        ";
        
        $products_stmt = $conn->prepare($products_query);
        $products_stmt->execute([$period_start, $period_end]);
        $top_product = $products_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get all products sold with quantities
        $all_products_query = "
            SELECT 
                p.product_name,
                SUM(oi.qty) as total_quantity,
                SUM(oi.amount) as total_revenue,
                COUNT(DISTINCT o.id) as order_count
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            JOIN products p ON oi.product_id = p.id
            WHERE DATE(o.created_at) BETWEEN ? AND ?
            GROUP BY p.id, p.product_name
            ORDER BY total_quantity DESC
        ";
        
        $all_products_stmt = $conn->prepare($all_products_query);
        $all_products_stmt->execute([$period_start, $period_end]);
        $all_products = $all_products_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get primary payment method
        $payment_query = "
            SELECT 
                payment_type,
                SUM(total_amount) as total
            FROM orders o
            WHERE DATE(o.created_at) BETWEEN ? AND ?
            GROUP BY payment_type
            ORDER BY total DESC
            LIMIT 1
        ";
        
        $payment_stmt = $conn->prepare($payment_query);
        $payment_stmt->execute([$period_start, $period_end]);
        $payment_method = $payment_stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get detailed sales data
        $detailed_query = "
            SELECT 
                DATE(o.created_at) as sale_date,
                COUNT(o.id) as orders_count,
                SUM(o.total_amount) as daily_total
            FROM orders o 
            WHERE DATE(o.created_at) BETWEEN ? AND ?
            GROUP BY DATE(o.created_at)
            ORDER BY DATE(o.created_at) ASC
        ";
        
        $detailed_stmt = $conn->prepare($detailed_query);
        $detailed_stmt->execute([$period_start, $period_end]);
        $daily_sales = $detailed_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Compile all data
        $sales_data = [
            'daily_breakdown' => $daily_sales,
            'summary' => $summary,
            'top_product_details' => $top_product,
            'payment_method_details' => $payment_method,
            'products_sold' => $all_products
        ];
        
        // Insert archive
        $insert_query = "
            INSERT INTO sales_archives (
                archive_type, period_start, period_end, 
                total_orders, total_sales, avg_order_value, 
                paid_sales, unpaid_sales, 
                top_product, top_product_revenue, 
                primary_payment_method, sales_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ";
        
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->execute([
            $archive_type,
            $period_start,
            $period_end,
            $summary['total_orders'] ?? 0,
            $summary['total_sales'] ?? 0.00,
            $summary['avg_order_value'] ?? 0.00,
            $summary['paid_sales'] ?? 0.00,
            $summary['unpaid_sales'] ?? 0.00,
            $top_product['product_name'] ?? 'N/A',
            $top_product['total_revenue'] ?? 0.00,
            $payment_method['payment_type'] ?? 'N/A',
            json_encode($sales_data)
        ]);
        
        return ['success' => true, 'message' => "Successfully archived {$archive_type} data for {$period_start} to {$period_end}"];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => "Error archiving data: " . $e->getMessage()];
    }
}

/**
 * Clean up old archives based on retention policy
 */
function cleanupOldArchives($conn) {
    $results = [];
    
    try {
        // Clean daily archives older than 7 days
        $daily_cutoff = date('Y-m-d', strtotime('-7 days'));
        $daily_query = "DELETE FROM sales_archives WHERE archive_type = 'daily' AND period_end < ?";
        $daily_stmt = $conn->prepare($daily_query);
        $daily_stmt->execute([$daily_cutoff]);
        $daily_deleted = $daily_stmt->rowCount();
        
        if ($daily_deleted > 0) {
            $results[] = "Deleted {$daily_deleted} daily archive(s) older than 7 days";
        }
        
        // Clean weekly archives older than 30 days
        $weekly_cutoff = date('Y-m-d', strtotime('-30 days'));
        $weekly_query = "DELETE FROM sales_archives WHERE archive_type = 'weekly' AND period_end < ?";
        $weekly_stmt = $conn->prepare($weekly_query);
        $weekly_stmt->execute([$weekly_cutoff]);
        $weekly_deleted = $weekly_stmt->rowCount();
        
        if ($weekly_deleted > 0) {
            $results[] = "Deleted {$weekly_deleted} weekly archive(s) older than 30 days";
            
            $log_stmt = $conn->prepare($log_query);
            $log_stmt->execute(['weekly', 'cleanup', $weekly_deleted, "Deleted {$weekly_deleted} old weekly archives"]);
        }
        
        // Clean monthly archives older than 180 days (6 months)
        $monthly_cutoff = date('Y-m-d', strtotime('-180 days'));
        $monthly_query = "DELETE FROM sales_archives WHERE archive_type = 'monthly' AND period_end < ?";
        $monthly_stmt = $conn->prepare($monthly_query);
        $monthly_stmt->execute([$monthly_cutoff]);
        $monthly_deleted = $monthly_stmt->rowCount();
        
        if ($monthly_deleted > 0) {
            $results[] = "Deleted {$monthly_deleted} monthly archive(s) older than 180 days";
            
            $log_stmt = $conn->prepare($log_query);
            $log_stmt->execute(['monthly', 'cleanup', $monthly_deleted, "Deleted {$monthly_deleted} old monthly archives"]);
        }
        
        if (empty($results)) {
            $results[] = "No old archives to clean up";
        }
        
        return ['success' => true, 'messages' => $results];
        
    } catch (Exception $e) {
        return ['success' => false, 'messages' => ["Error during cleanup: " . $e->getMessage()]];
    }
}
