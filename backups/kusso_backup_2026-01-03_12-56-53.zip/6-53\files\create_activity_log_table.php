<?php
// Create inventory_activity_log table
include('includes/config.php');

try {
    $sql = "CREATE TABLE IF NOT EXISTS inventory_activity_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ingredient_id INT NOT NULL,
        ingredient_name VARCHAR(255) NOT NULL,
        quantity_added DECIMAL(10,2) NOT NULL,
        unit VARCHAR(50) NOT NULL,
        user_name VARCHAR(255),
        user_role VARCHAR(50),
        action_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (ingredient_id) REFERENCES ingredients(id) ON DELETE CASCADE
    )";
    
    $conn->exec($sql);
    echo "Table 'inventory_activity_log' created successfully!";
} catch (PDOException $e) {
    echo "Error creating table: " . $e->getMessage();
}
?>
